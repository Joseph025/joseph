import os


g_word_segment_white_file = os.path.join(os.path.dirname(os.getcwd()), \
                                          'idms_v2', \
                                          'src', \
                                          'cfg', \
                                          'whiteList.txt')


g_word_segment_black_files  = os.path.join(os.path.dirname(os.getcwd()), \
                                           'idms_v2', \
                                          'src', \
                                          'cfg', \
                                          'blackList.txt')
